Rules:
Do not commit if you have deleted files, or large contents of files. Ask user dorectly if changes are ok to push and if you have verified already.
Do not run any Destructive git commnd unless directly asked.
Do not add placeholders for code to be put in later. Never have examples or placeholders.
When commit, Do not label your release as a prerelease, as the kernel is in alpha pre release and also provide release notes like bug fixes and improvements and new features if any along with the release, formatted in md.
