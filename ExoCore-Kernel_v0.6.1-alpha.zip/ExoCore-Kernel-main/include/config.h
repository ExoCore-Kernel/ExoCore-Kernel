#ifndef EXOCORE_CONFIG_H
#define EXOCORE_CONFIG_H

/* Enable run-directory modules */
#define FEATURE_RUN_DIR 1

#endif /* EXOCORE_CONFIG_H */
