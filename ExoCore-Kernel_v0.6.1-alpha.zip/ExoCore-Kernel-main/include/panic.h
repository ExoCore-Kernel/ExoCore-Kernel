#ifndef PANIC_H
#define PANIC_H

void panic(const char *msg);

#endif /* PANIC_H */
