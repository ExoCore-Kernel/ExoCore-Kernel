#ifndef PS2KBD_H
#define PS2KBD_H
#include <stdint.h>

uint8_t ps2kbd_read_scancode(void);

#endif /* PS2KBD_H */
